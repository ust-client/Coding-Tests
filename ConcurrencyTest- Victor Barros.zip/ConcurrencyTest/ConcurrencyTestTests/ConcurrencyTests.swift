//
//  ConcurrencyTestTests.swift
//  ConcurrencyTestTests
//


import XCTest
@testable import ConcurrencyTest

class ConcurrencyTests: XCTestCase {
    
    func testLoadMessageTimeout() {
        let expectationsLoadMessage = expectation(description: "Load Message")
        
        var message: String? = nil
        
        loadMessage(timeout: .now()) {
            message = $0
            XCTAssertTrue(Thread.current.isMainThread)
            expectationsLoadMessage.fulfill()
        }
        
        waitForExpectations(timeout: 5)
        
        XCTAssertNotNil(message)
        XCTAssertEqual(message, "Unable to load message - Time out exceeded")
    }
    
    func testLoadMessageSuccess() {
        let expectationsLoadMessage = expectation(description: "Load Message")
        
        var message: String? = nil
        
        loadMessage(timeout: .now() + .seconds(5)) {
            message = $0
            XCTAssertTrue(Thread.current.isMainThread)
            expectationsLoadMessage.fulfill()
        }
        
        waitForExpectations(timeout: 10)
        
        XCTAssertNotNil(message)
        XCTAssertEqual(message, "Hello world")
    }

}
