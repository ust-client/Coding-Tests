//
//  ViewController.swift
//  ConcurrencyTest
//


import UIKit

class ViewController: UIViewController {

    let label = UILabel(frame: .zero)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLabel()
        label.text = "loading"
        
        fetchMessage()
    }
	
	deinit {
		print("ViewController has been deinitialized")
	}
	
	
	/// Fetch String to be displayed in center label
	func fetchMessage() {
		loadMessage { [weak self] combinedMessage in
			guard let self = self else { return }
			
			DispatchQueue.main.async {
				self.label.text = combinedMessage
			}
		}
	}
}

extension ViewController {
	
	/// Adds label to the view and sets constraints
    private func setupLabel() {
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
		
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
}
