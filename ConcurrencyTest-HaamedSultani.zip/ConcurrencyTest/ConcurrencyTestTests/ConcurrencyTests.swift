//
//  ConcurrencyTestTests.swift
//  ConcurrencyTestTests
//


import XCTest
@testable import ConcurrencyTest

class ConcurrencyTests: XCTestCase {
	
	
	/// Loads message with 3 second timeout
	func testloadMessage() {
		
		loadMessage(withTimeout: 3) { (message) in
			
			XCTAssertEqual(message, "Hello world")
		}
    }
	
	/// Tests message timing out
	func testLoadMessageTimeout() {
		loadMessage(withTimeout: 0) { (message) in
			XCTAssertEqual(message, "Unable to load message - Time out exceeded")
		}
	}
	
	/// Test examines asynchronous timeout of loading Message One
	func testLoadingMessageOne() {
		let messageOneExpectation = self.expectation(description: "Expectation: fetching message one")
		
		fetchMessageOne { (messageOne) in
			messageOneExpectation.fulfill()
		}
		
		let waiterResult = XCTWaiter().wait(for: [messageOneExpectation], timeout: 2)
		
		switch waiterResult {
			case .completed: print("Message One Fulfillfed succesfully")
			case .timedOut: print("Message One Timed out")
			default: print("Expectation error")
		}
	}
	
	/// Test examines asynchronous timeout of loading Message Two
	func testLoadingMessageTwo() {
		let messageTwoExpectation = self.expectation(description: "Expectation: fetching message two")
		
		fetchMessageTwo { (messageTwo) in
			messageTwoExpectation.fulfill()
		}
		
		let waiterResult = XCTWaiter().wait(for: [messageTwoExpectation], timeout: 2)
		
		switch waiterResult {
			case .completed: print("Message Two Fulfillfed succesfully")
			case .timedOut: print("Message Two Timed out")
			default: print("Expectation error")
		}
	}

}
