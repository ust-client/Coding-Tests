# Sample Test

## Instructions

* Open the Xcode project
* Use Swift 4.2
* Read the instructions in Concurrency.swift
* After you have completed your test
    * Create a zip file containing your code and the git history.
        * Name this file ConcurrencyTest-YourName.zip
    * Email this to your HSBC contact
