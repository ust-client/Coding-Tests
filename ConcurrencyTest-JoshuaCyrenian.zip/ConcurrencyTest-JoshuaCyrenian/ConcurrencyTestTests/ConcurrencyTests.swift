//
//  ConcurrencyTestTests.swift
//  ConcurrencyTestTests
//


import XCTest
@testable import ConcurrencyTest

class ConcurrencyTests: XCTestCase {
    
    let dispatchGroup = DispatchGroup() // global DispatchGroup constant
    var message: String? // variable for holding message returned by loadMessage function
    
    func testloadMessage() {
        
        self.dispatchGroup.enter() // start DispatchGroup
        
        loadMessage
        { (combinedMessage) in
            self.message = combinedMessage // set global message variable to received message
            self.dispatchGroup.leave() // end of DispatchGroup execution
        }
        
        // when DispatchGroup has finished executing
        self.dispatchGroup.notify(queue: .main) {
            XCTAssert(self.message != nil) // test if message is nil
        }
    }
    
    func testTimeOut() {
        
        self.dispatchGroup.enter() // start DispatchGroup
        
        loadMessage
        { (combinedMessage) in
            self.message = combinedMessage // set global message variable to received message
            self.dispatchGroup.leave() // end of DispatchGroup execution
        }
        
        // wait up to 3 seconds for loadMessage to complete
        let waitResult: DispatchTimeoutResult = dispatchGroup.wait(timeout: .now() + 3)
        
        // if DispatchGroup has waited and finished in less than 3 seconds
        if (waitResult == .success)
        {
            // when DispatchGroup has finished executing
            self.dispatchGroup.notify(queue: .main) {
                XCTAssert(self.message == "Unable to load message - Time out exceeded") // test if message has timed out based on message description
            }
        }
    }
}
