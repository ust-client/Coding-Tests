//
//  Concurrency.swift


import Foundation

/// To complete this task, fill out the `loadMessage` method below this comment.
///
///  * Read the requirements defined below.
///  * Feel free to research solutions on the interent, but don't copy and paste code.
///  * Do track your progress in git and submit the project with git history.
///  * Don't use external libraries such as PromiseKit / RXSwift.
///
/// # Background
///
/// We have created two data sources `fetchMessageOne` & `fetchMessageTwo`
/// that load two parts of a messaage. These mimic loading data from the network and call their completion handlers in 0-2 seconds.
/// (You don't need to look at the source code for these functions, but you should know they complete at random times between runs).
///
///
/// # Requirements Part 1
///
/// This function should fetch both parts of the message (concurrently using GCD or OperationQueue) and join them with
/// a space. e.g if `fetchMessageOne` completes with "Good" and `fetchMessageTwo` completes with "morning!" then loadMessage should call it's completion once with the String:
///   "Good morning!"
/// If loading either part of the message takes more than 2 seconds then `loadMessage` should complete with the String
///   "Unable to load message - Time out exceeded"
///
/// The function should only complete once and must always return the full message in the correct order.
///
/// # Requirements Part 2
///
/// Refactor this function to use idomatic Swift code.
/// Follow the apple Swift naming guidelines. If you choose you can abstract classes, structs, protocols, enums, generics etc.
///
/// # Requirements Part 3
///
/// Refactor this function so it is easy to unit test.
/// Write unit tests that verify both the successful loading & timeout behaviour. These tests must be deterministic.
///
/// # Requirement Part 4
/// * The completion handler should always be called on the main thread.
/// * If loadMessage is called on the main thread, loadMessage should not block the main thread.
///
///
/// How we assess this task
///
/// * Completed functional requirements
/// * Deterministic Unit tests
/// * Code readability & matching apple naming guidelines
/// * Showing work through git history
///
func loadMessage(completion: @escaping (String) -> Void)
{
    let maximumWaitTime: Double = 2 // constant for maximum wait time to retrieve message from fetchMessage functions
    
    var message: [Int: String?] = [1: nil, 2: nil] // dictionary for holding two optional message values from fetchMessage functions
    var messageToUser: String = "" // message to be displayed to user
    
    let firstDispatchGroup = DispatchGroup() // DispatchGroup for first message from fetchMessageOne
    let secondDispatchGroup = DispatchGroup() // DispatchGroup for second message from fetchMessageTwo
    
    firstDispatchGroup.enter() // start first DispatchGroup
    secondDispatchGroup.enter() // start second DispatchGroup
    
    fetchMessageOne
    { (messageOne) in
        message[1] = messageOne // first message dictionary element is set
        firstDispatchGroup.leave() // end of first DispatchGroup execution
    }
   
    fetchMessageTwo
    { (messageTwo) in
        message[2] = messageTwo // second message dictionary element is set
        secondDispatchGroup.leave() // end of second DispatchGroup execution
    }
    
    let firstMessageWaitResult: DispatchTimeoutResult = firstDispatchGroup.wait(timeout: .now() + maximumWaitTime) // set maximum execution time of firstDispatchGroup to maximumWaitTime
    let secondMessageWaitResult: DispatchTimeoutResult = secondDispatchGroup.wait(timeout: .now() + maximumWaitTime) // set maximum execution time of secondDispatchGroup to maximumWaitTime
    
    // when DispatchGroups have finished executing
    secondDispatchGroup.notify(queue: .main)
    {
        // if DispatchGroups have finished waiting for up to seconds in maximumWaitTime
        if (firstMessageWaitResult == .success && secondMessageWaitResult == .success)
        {
            // make sure first and second message aren't nil values
            guard let messageOne = message[1], let messageTwo = message[2] else {
                messageToUser = "error receiving message" // notify user that one or more message values have not been set
                return
            }
            
            messageToUser = "\(messageOne!) \(messageTwo!)" // combine two messages into one
        }
        else
        {
            messageToUser = "Unable to load message - Time out exceeded" // notify user of high execution time
        }
        
        completion(messageToUser) // display message to user
    }
}
