//
//  ConcurrencyTestTests.swift
//  ConcurrencyTestTests
//


import XCTest
@testable import ConcurrencyTest

class ConcurrencyTests: XCTestCase {
    
    var concurrencyManager: ConcurrencyManager!
    
    override func setUp() {
        super.setUp()
        concurrencyManager = ConcurrencyManager()
    }
    
    func testloadMessage() {
        concurrencyManager.loadMessage { combinedMessage, timeToComplete in
            XCTAssert(combinedMessage == "hello world" || combinedMessage == "Unable to load message - Time out exceeded")
        }
    }
    
    func testTimeoutBehaviourGreaterThanZero() {
        concurrencyManager.loadMessage { combinedMessage, timeToComplete in
            if(timeToComplete > 0) {
                XCTAssert(combinedMessage == "hello world")
            }
        }
    }
    
    func testTimeoutBehaviourEqualToZero() {
        concurrencyManager.loadMessage { combinedMessage, timeToComplete in
            if(timeToComplete == 0) {
                XCTAssert(combinedMessage == "Unable to load message - Time out exceeded")
            }
        }
    }
    
    func testTimerIsValidOnLoad() {
        concurrencyManager.performTimer()
        XCTAssertNotNil(self.concurrencyManager.countdownTimer)
    }

    func testTimerIsValidGreaterThanZero() {
        concurrencyManager.loadMessage { combinedMessage, timeToComplete in
            if(timeToComplete > 0) {
                XCTAssertNotNil(self.concurrencyManager.countdownTimer)
            }
        }
    }
    
    func testTimerIsInvalied() {
        concurrencyManager.loadMessage { combinedMessage, timeToComplete in
            if(timeToComplete == 0) {
                // Pausing for two seconds to give time for timer countdownTimer to invalidate
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    XCTAssertNil(self.concurrencyManager.countdownTimer)
                }
            }
        }
    }
    
}
