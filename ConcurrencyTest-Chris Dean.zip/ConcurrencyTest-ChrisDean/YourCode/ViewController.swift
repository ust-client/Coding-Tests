//
//  ViewController.swift
//  ConcurrencyTest
//


import UIKit

class ViewController: UIViewController {
    
    // Perhaps make this a weak var
    var label = UILabel(frame: .zero)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLabel()
        
        label.text = "loading"
        
        // Maybe call loadMessage in here. Refer to requirement 4
        //DispatchQueue.main.async {}
        let concurrencyManager = ConcurrencyManager()
        concurrencyManager.loadMessage { combinedMessage, timeToComplete  in
            DispatchQueue.main.async {
                self.label.text = combinedMessage
            }
        }
    }
}

extension ViewController {
    private func setupLabel() {
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            (label.centerXAnchor.constraint(equalTo: view.centerXAnchor)),
            (label.centerYAnchor.constraint(equalTo: view.centerYAnchor))
        ])
    }
}
