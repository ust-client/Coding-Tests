//
//  ConcurrencyTestTests.swift
//  ConcurrencyTestTests
//


import XCTest
@testable import ConcurrencyTest

class ConcurrencyTests: XCTestCase {
    func testloadMessage1() {
        var result: String?
        loadMessage(isTest: true, wait: 3.0) { string in
            result = string
        }
        
        XCTAssert(result == "Hello world")
    }
    
    func testloadMessage2() {
        var result: String?
        
        loadMessage(isTest: true, wait: 0.0) { string in
            result = string
        }
        XCTAssert(result == "Unable to load message - Time out exceeded")
    }

}
