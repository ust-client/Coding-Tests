//
//  ConcurrencyTestTests.swift
//  ConcurrencyTestTests
//


import XCTest
@testable import ConcurrencyTest

class ConcurrencyTests: XCTestCase {
    let testMessage = Message()
    
    func testloadMessage() {
        let stringExpectation = expectation(description: "fetch Hello world")
        var message: String?
        
        testMessage.loadMessage { (combinedMessage) in
            message = combinedMessage
            stringExpectation.fulfill()
        }
        
        waitForExpectations(timeout: 2) { (error) in
            print(error?.localizedDescription ?? "message takes more than 2 seconds")
        }
        XCTAssertEqual(message, "Hello world", "combinedMessage must be -> Hello world")
    }
    
    func testMessageOne() {
        let stringExpectation = expectation(description: "fetch Hello")
        var message: String?
        
        testMessage.loadMessageOne { (messageOne) in
            message = messageOne
            stringExpectation.fulfill()
        }
       
        waitForExpectations(timeout: 2) { (error) in
            print(error?.localizedDescription ?? "message takes more than 2 seconds")
        }
        XCTAssertEqual(message, "Hello", "message must be -> Hello")
    }
    
    func testMessageTwo() {
        let stringExpectation = expectation(description: "fetch world")
        var message: String?
        
        testMessage.loadMessageTwo { (messageTwo) in
            message = messageTwo
            stringExpectation.fulfill()
        }
        
        waitForExpectations(timeout: 3) { (error) in
            print(error?.localizedDescription ?? "message takes more than 2 seconds")
        }
        XCTAssertEqual(message, "world", "message must be -> world")
    }
    
}
